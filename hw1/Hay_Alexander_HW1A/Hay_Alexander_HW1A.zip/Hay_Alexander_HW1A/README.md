# HW1A - Search and Navigation

Alexander Hay
ME 469, HW1, Part A

## Preface

Not included are 7 files used for reference regarding different aspects of the code. This project is a good reason to use classes in Python but I am very new to OOP.

At the moment, the code does not work. There is a more complete version but I do not want to submit it because the meat of the code is used from an article found online. It's included for reference but it also does not work.
