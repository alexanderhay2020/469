Alexander Hay
ME 469, HW0, Part A

Preface

There are 3 executable files.
I had already started programming as separate files before I learned that just 1 was preferred.
I continued as is, because I'm not experienced in coding well enough to do that without taking a lot of time or making a complete mess.
I'll make this a single executable for part B

----------------------------------------------------------

pt3

I was able to successfully plot the groundtruth data and the robot's odometry data
I was not able to plot the dead reckoning correctly. I suspect my math is not correct. While I think the meat of it is correct I'm missing something critical. This was one of the last things I implemented, hence not addressing it during office hours.

----------------------------------------------------------

pt6

Please note the terminal output
