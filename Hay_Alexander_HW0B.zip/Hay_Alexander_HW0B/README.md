Alexander Hay
ME 469, HW0, Part A

Preface

There are 3 executable files.
I had already started programming as separate files before I learned that just 1 was preferred.
I continued as is, because I'm not experienced in coding well enough to do that without taking a lot of time or making a complete mess.
I'll make this a single executable for part B
----------------------------------------------------------

pt6

Please note the terminal ouput
